package com.hospital.repo;

import org.springframework.data.jpa.repository.JpaRepository;

//import org.springframework.data.repository.CrudRepository;

import com.hospital.entity.Position;

public interface PositionRepository extends JpaRepository<Position, Integer> {

}
