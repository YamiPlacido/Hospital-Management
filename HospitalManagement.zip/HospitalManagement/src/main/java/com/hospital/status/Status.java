package com.hospital.status;

public class Status {
    public static final int CREATED = 1;
    public static final int SENT = 2;
    public static final int DOING = 3;
    public static final int FINISHED = 4;
}
