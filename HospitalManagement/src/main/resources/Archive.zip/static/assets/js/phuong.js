$(document).ready(function() {
	$("#load-more").click();
});
var currentPage = 1;

$("#load-more").click(function() {
	$.ajax({	type : "GET",
				url : '/admin/doctor?current_page='+currentPage,
				contentType : 'application/json',
				success : function(data, status) {
					currentPage +=1;
					var insert_content;
					jQuery.each(data,function(i, val) {
										insert_content = '<div class="col-md-4 col-sm-4 col-lg-3">';
										insert_content += '<div class="profile-widget">';
										insert_content += '<div class="doctor-img">';
										insert_content += '<a class="avatar" href="doctor/'+ val.doctorId 
												+ '"><img alt="" src="/upload/'
												+ val.imagePath
												+ '"></a>';
										insert_content += '</div>';
										insert_content += '<div class="dropdown profile-action">';
										insert_content += '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>';
										insert_content += '<div class="dropdown-menu dropdown-menu-right">';
										insert_content += '<a class="dropdown-item" href="/doctor/edit/' + val.doctorId + '"><i class="fa fa-pencil m-r-5"></i> Edit</a>';
										insert_content += '<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_doctor"><i class="fa fa-trash-o m-r-5"></i> Delete</a>';
										insert_content += '</div>';
										insert_content += '</div>';
										insert_content += '<h4 class="doctor-name text-ellipsis"><a href="profile.html">'
												+ val.firstName + ' ' + val.lastName
												+ '</a></h4>';
										insert_content += '<div class="doc-prof">'
												+ val.speciality.name
												+ '</div>';
										insert_content += '<div class="user-country">';
										insert_content += '<i class=""></i> '
												+ val.code + '';
										insert_content += '</div>';
										insert_content += '</div>';
										insert_content += '</div>';

										$("#doctor-container")
												.append(
														insert_content);
										insert_content = '';
									});
				}
			});
		});


function deleteDoctor(id) {
	$.ajax({
		type : "DELETE",
		url : '/admin/doctor?id=' + id,
		//				contentType : 'application/json',
		success : function(data, status) {
			window.location.replace("http://localhost:8080/doctor");
		}
	});
}

$( "#position" ).change(function() {
	var id = $("#position").val();
	$.ajax({
		type : "GET",
		url : '/system/speciality?position_id=' + id,
		success : function(data, status) {
			$("#speciality").empty();
			var insert_content;
			jQuery.each(data,function(i, val) {
				insert_content = '<option value="'+val.specialityId+'">'+val.name+'</option>';

				$("#speciality")
					.append(
						insert_content);
				insert_content = '';
			});
		}
	});
});

$('#select-symptom').multiSelect({
	selectableHeader: "<input type='text' class='search-input form-control' autocomplete='off' placeholder='symptom' onfocus=\"this.placeholder = ''\"\n" +
		"onblur=\"this.placeholder = 'symptom'\">",
	afterInit: function(ms){
		var that = this,
			$selectableSearch = that.$selectableUl.prev(),
			selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)';

		that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
			.on('keydown', function(e){
				if (e.which === 40){
					that.$selectableUl.focus();
					return false;
				}
			});

	},
	afterSelect: function(){
		this.qs1.cache();
	},
	afterDeselect: function(){
		this.qs1.cache();
	}
});

$('#select-examination').multiSelect({
	selectableHeader: "<input type='text' class='search-input form-control' autocomplete='off' placeholder='examination' onfocus=\"this.placeholder = ''\"\n" +
		"onblur=\"this.placeholder = 'examination'\">",
	afterInit: function(ms){
		var that = this,
			$selectableSearch = that.$selectableUl.prev(),
			selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)';

		that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
			.on('keydown', function(e){
				if (e.which === 40){
					that.$selectableUl.focus();
					return false;
				}
			});

	},
	afterSelect: function(){
		this.qs1.cache();
	},
	afterDeselect: function(){
		this.qs1.cache();
	}
});
