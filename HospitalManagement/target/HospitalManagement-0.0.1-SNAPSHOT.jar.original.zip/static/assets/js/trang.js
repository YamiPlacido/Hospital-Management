//$(document).ready(function () {
//    _getAll();
//});
//
//function _getAll() {
//    $.ajax({
//    	url : '/appointment/list',
//        type: "GET",
//        contentType: "application/json",
//        success: function (data, status) {
//            var html;
//            jQuery.each(data, function (key, item) {
//                html += '<tr>';
//                html += '<td>' + item.patient.name + '</td>';
//                html += '<td>' + item.doctor.name + '</td>';
//                html += '<td>' + item.date + '</td>';
//                html += '<td>' + item.status + '</td>';
//                html += '<td><a href="#" onclick="return _getById(' + item.appId + ')">Edit</a> | <a href="#" onclick="return _delete(' + item.appId + ')">Delete</a></td>';
//                html += '</tr>';
//            });
//            $('#list tbody').append(
//            		html);
//            html = '';
//        
//    }
//});
//}
//
////$("#load-more")
////		.click(
////				function() {
////					$.ajax({
////								type : "GET",
////								url : '/admin/appointment',
////								contentType : 'application/json',
////								//        data: data,
////								success : function(data, status) {
////									var insert_content;
////									jQuery
////											.each(
////													data,
////													function(i, val) {
////														insert_content = 
////														insert_content += '<div class="doc-prof">'
////																+ val.speciality.name
////																+ '</div>';
////														insert_content += '<div class="user-country">';
////														insert_content += '<i class=""></i> '
////																+ val.code + '';
////														insert_content += '</div>';
////														insert_content += '</div>';
////														insert_content += '</div>';
////
////														$("#app-container")
////																.append(
////																		insert_content);
////														insert_content = '';
////													});
////
////								}
////							});
////				});
//
////function showDetail(id) {
////	var insert_content='';
////	var back_button = '<button type="button" class="btn btn-secondary" id="back-button">Load More</button>';
////	$.ajax({
////				type : "GET",
////				url : '/admin/doctor/' + id,
////				contentType : 'application/json',
////				success : function(data, status) {
////					insert_content += '<div class="card-box profile-header">';
////					insert_content += '<div class="row">';
////					insert_content += '<div class="col-md-12">';
////					insert_content += '<div class="profile-view">';
////					insert_content += '<div class="profile-img-wrap">';
////					insert_content += '<div class="profile-img">';
////					insert_content += '<a href="#"><img class="avatar" src="/assets/img/'+data.imagePath+'" alt=""></a>';
////					insert_content += '</div>';
////					insert_content += '</div>';
////					insert_content += '<div class="profile-basic">';
////					insert_content += ' <div class="row">';
////					insert_content += '   <div class="col-md-5">';
////					insert_content += '  <div class="profile-info-left">';
////					insert_content += '   <h3 class="user-name m-t-0 mb-0">'+data.name+'</h3>';
////					insert_content += '  <small class="text-muted">'+data.speciality.name+'</small>';
////					insert_content += '  <div class="staff-id">Employee ID: '+data.code+'</div>';
////					insert_content += ' <div class="staff-msg"><a href="chat.html" class="btn btn-primary">Send Message</a></div>';
////					insert_content += '  </div>';
////					insert_content += ' </div>';
////					insert_content += ' <div class="col-md-7">';
////					insert_content += '   <ul class="personal-info">';
////					insert_content += '    <li>';
////					insert_content += '     <span class="title">Phone:</span>';
////					insert_content += '  <span class="text"><a href="#">'+data.phone+'</a></span>';
////					insert_content += ' </li>';
////					insert_content += '      <li>';
////					insert_content += '    <span class="title">Email:</span>';
////					insert_content += '          <span class="text"><a href="#">'+data.email+'</a></span>';
////					insert_content += '       </li>';
////					insert_content += '           <li>';
////					insert_content += '        <span class="title">Birthday:</span>';
////					insert_content += '       <span class="text">'+data.dob+'</span>';
////					insert_content += '        </li>';
////					insert_content += '   <li>';
////					insert_content += '             <span class="title">Address:</span>';
////					insert_content += '             <span class="text">'+data.address+'</span>';
////					insert_content += '      </li>';
////					insert_content += '                    <li>';
////					insert_content += '   <span class="title">Gender:</span>';
////					insert_content += '                   <span class="text">Female</span>';
////					insert_content += '      </li>';
////					insert_content += '    </ul>';
////					insert_content += '          </div>';
////					insert_content += '     </div>';
////					insert_content += '        </div>';
////					insert_content += '       </div>   ';
////					insert_content += '     </div>';
////					insert_content += '  </div>';
////					insert_content += '</div>';
////					$("#doctor-container").replaceWith(insert_content);
////					$("#load-more").replaceWith(back_button);
////				}
////			});
////}