drop table patient;
create table patient(
	patient_id int not null auto_increment primary key, 
	name varchar(255) not null, 
	DOB TIMESTAMP not null default CURRENT_TIMESTAMP(),
	address varchar(255) not null,
	email varchar(255) not null,
	phone varchar(255) not null,
	image_url blob,
	patient_note text
);

insert into patient(name,DOB,address,email,phone) values 
('Nguyen Thi Thuy Trang', '2000-09-17', 'Nguyen Van Troi Street', 'trangnguyen121293@gmail.com','098737374');

-- Table DOCTOR
drop table doctor;
create table doctor(
    doctor_id int primary key ,
    name varchar(255) not null
);

insert into doctor values
(1,'Michael Owen');

drop table appointment;
-- Table APPOINTMENT
create table appointment(
	app_id int not null auto_increment primary key, 
	patient_id int not null,
	doctor_id int,
	date TIMESTAMP not null default CURRENT_TIMESTAMP(),
	location varchar(255) not null,
	status boolean not null default false,
	note text,
	foreign key (patient_id) references patient(patient_id),
	foreign key (doctor_id) references doctor(doctor_id)
);
insert into appointment(patient_id,doctor_id,date,location,status) values
(1,1,'2019-12-11','Nguyen Van Troi Street',false);
